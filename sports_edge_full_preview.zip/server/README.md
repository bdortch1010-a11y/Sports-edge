# Live Data Backend

Use this server as the secure aggregation layer. Keep all provider secrets server-side.

Recommended normalized endpoints:
- GET /api/picks
- GET /api/games
- GET /api/injuries
- GET /api/weather
- GET /api/news
- GET /api/lines/movement

Data adapters should use licensed commercial feeds and preserve:
- provider name
- source timestamp
- market timestamp
- game start time
- injury status timestamp
- weather forecast timestamp

The mobile app should never receive provider API secrets.
