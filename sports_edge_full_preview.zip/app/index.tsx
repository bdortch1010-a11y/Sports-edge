import {useMemo,useState} from "react";
import {SafeAreaView,ScrollView,Text,View,Pressable,StyleSheet} from "react-native";
import {Ionicons} from "@expo/vector-icons";

const G="#D4AF37",BG="#050505",CARD="#101010",CARD2="#151515",M="#888";
type Pick={id:string;league:string;matchup:string;market:string;line:string;prob:number;conf:number;reason:string;injury:string;weather:string};
const picks:Pick[]=[
{id:"1",league:"NFL",matchup:"Chiefs @ Bills",market:"Moneyline",line:"Chiefs -125",prob:72,conf:8,reason:"Strong efficiency profile and matchup edge.",injury:"Bills WR questionable",weather:"42°F • light rain • 12 mph wind"},
{id:"2",league:"NFL",matchup:"Chiefs @ Bills",market:"Spread",line:"Chiefs -3.5",prob:68,conf:7,reason:"Model favors Kansas City by 4.8 points.",injury:"Chiefs LT probable",weather:"42°F • light rain • 12 mph wind"},
{id:"3",league:"NBA",matchup:"Lakers @ Warriors",market:"Spread",line:"Lakers +4.5",prob:56,conf:6,reason:"Recent pace and rebounding keep the game close.",injury:"Lakers starter questionable",weather:"Indoor • no weather impact"},
{id:"4",league:"NBA",matchup:"Celtics @ Heat",market:"Total",line:"Over 229.5",prob:62,conf:7,reason:"Possession model projects a higher scoring environment.",injury:"Heat guard probable",weather:"Indoor • no weather impact"},
{id:"5",league:"MLB",matchup:"Braves @ Mets",market:"Moneyline",line:"Braves -120",prob:64,conf:7,reason:"Starting-pitcher and bullpen inputs favor Atlanta.",injury:"Mets OF day-to-day",weather:"58°F • clear • 7 mph wind"}
];

const news=[
["NFL","Chiefs-Bills practice report updated","2h ago"],
["NBA","Lakers update: Davis listed as questionable","3h ago"],
["MLB","Braves keep rolling with five-run 5th","4h ago"],
["NFL","Top 5 fantasy sleepers for Week 10","5h ago"]
];

function Confidence({v}:{v:number}){return <View style={s.conf}><Text style={s.confNum}>{v}/10</Text><Text style={s.confLabel}>CONFIDENCE</Text></View>}
function Pick({p,selected,onToggle}:{p:Pick;selected:boolean;onToggle:()=>void}){
 return <View style={s.pick}>
  <View style={s.row}><View style={{flex:1}}><Text style={s.kicker}>{p.league} • {p.market}</Text><Text style={s.match}>{p.matchup}</Text></View><Confidence v={p.conf}/></View>
  <View style={s.priceRow}><Text style={s.price}>{p.line}</Text><Text style={s.prob}>{p.prob}% model probability</Text></View>
  <Text style={s.reason}>{p.reason}</Text>
  <Text style={s.meta}>✚ {p.injury}</Text><Text style={s.meta}>☁ {p.weather}</Text>
  <Pressable onPress={onToggle} style={[s.btn,selected&&s.btnOn]}><Text style={s.btnText}>{selected?"✓ ADDED TO PARLAY":"+ ADD TO PARLAY"}</Text></Pressable>
 </View>
}

function Header(){return <View style={s.header}><View><Text style={s.logo}>SPORTS <Text style={s.gold}>EDGE</Text></Text><Text style={s.tag}>SMARTER PICKS. MORE CONTEXT.</Text></View><View style={s.crown}><Ionicons name="shield-checkmark" size={17} color={G}/></View></View>}

export default function App(){
 const [screen,setScreen]=useState("Home"); const [sel,setSel]=useState<string[]>([]);
 const selected=useMemo(()=>picks.filter(p=>sel.includes(p.id)),[sel]);
 const toggle=(id:string)=>setSel(x=>x.includes(id)?x.filter(i=>i!==id):[...x,id]);

 const body=screen==="Home"?<ScrollView contentContainerStyle={s.content}>
  <View style={s.hero}><Text style={s.heroKicker}>AI-ASSISTED ANALYSIS</Text><Text style={s.heroTitle}>Today's strongest signals</Text><Text style={s.heroCopy}>Compare model probability, confidence, injuries and weather before making your own decision.</Text></View>
  <View style={s.filters}>{["All Sports","NFL","NBA","MLB"].map(x=><View key={x} style={[s.filter,x==="All Sports"&&s.filterActive]}><Text style={[s.filterText,x==="All Sports"&&s.filterActiveText]}>{x}</Text></View>)}</View>
  <Text style={s.section}>TOP PICKS</Text>{picks.map(p=><Pick key={p.id} p={p} selected={sel.includes(p.id)} onToggle={()=>toggle(p.id)}/>)}
 </ScrollView>
 :screen==="Parlay"?<ScrollView contentContainerStyle={s.content}><Text style={s.pageTitle}>PARLAY BUILDER</Text><Text style={s.muted}>{selected.length} legs selected</Text>
   {selected.length?selected.map(p=><Pick key={p.id} p={p} selected={true} onToggle={()=>toggle(p.id)}/>):<View style={s.empty}><Ionicons name="git-merge" size={36} color={G}/><Text style={s.emptyTitle}>Build your parlay</Text><Text style={s.muted}>Tap “Add to Parlay” on any pick.</Text></View>}
   {selected.length>0&&<View style={s.total}><Text style={s.totalLabel}>MODEL COMBINATION</Text><Text style={s.totalNum}>{Math.round(selected.reduce((a,p)=>a*p.prob/100,1)*100)}% estimated joint probability*</Text><Text style={s.disclaimer}>*Illustrative model calculation; outcomes are uncertain and legs are not necessarily independent.</Text></View>}
 </ScrollView>
 :screen==="News"?<ScrollView contentContainerStyle={s.content}><Text style={s.pageTitle}>NEWS & ANALYSIS</Text>{news.map(n=><View style={s.news} key={n[1]}><View style={s.newsIcon}><Ionicons name="newspaper-outline" size={22} color={G}/></View><View style={{flex:1}}><Text style={s.kicker}>{n[0]} • {n[2]}</Text><Text style={s.newsTitle}>{n[1]}</Text><Text style={s.muted}>Connect your licensed news feed for live updates.</Text></View></View>)}</ScrollView>
 :screen==="More"?<ScrollView contentContainerStyle={s.content}><Text style={s.pageTitle}>MORE</Text>{["Injuries & Lineups","Weather","My Picks / Results","Favorite Leagues","Notifications","Account & Billing","Privacy & Terms"].map((x,i)=><Pressable style={s.moreRow} key={x}><Ionicons name={(["medkit","cloud","bookmark","star","notifications","card","document-text"] as any)[i]} size={20} color={G}/><Text style={s.moreText}>{x}</Text><Ionicons name="chevron-forward" size={18} color={M}/></Pressable>)}<View style={s.notice}><Text style={s.noticeText}>Sports Edge is an analytics product. This build does not accept wagers, deposits or payouts.</Text></View></ScrollView>
 :null;

 return <SafeAreaView style={s.safe}><Header/>{body}
 <View style={s.nav}>{([["Home","home"],["My Picks","bookmark"],["Parlay","git-merge"],["News","newspaper"],["More","ellipsis-horizontal"]]).map(([x,ic])=><Pressable key={x} style={s.navItem} onPress={()=>setScreen(x)}><Ionicons name={ic as any} size={21} color={screen===x?G:M}/><Text style={[s.navText,screen===x&&s.navActive]}>{x}{x==="Parlay"&&sel.length?` (${sel.length})`:""}</Text></Pressable>)}</View>
 </SafeAreaView>
}

const s=StyleSheet.create({
safe:{flex:1,backgroundColor:BG},header:{height:72,paddingHorizontal:17,flexDirection:"row",justifyContent:"space-between",alignItems:"center",borderBottomWidth:1,borderBottomColor:"#1b1b1b"},logo:{fontSize:22,fontWeight:"900",color:"#fff",letterSpacing:1},gold:{color:G},tag:{fontSize:8,color:"#777",letterSpacing:1.7,marginTop:2},crown:{width:36,height:36,borderRadius:18,borderWidth:1,borderColor:"#4c411f",alignItems:"center",justifyContent:"center"},
content:{padding:15,paddingBottom:105},hero:{padding:19,borderRadius:17,backgroundColor:"#0d0c08",borderWidth:1,borderColor:"#3a3017",marginBottom:15},heroKicker:{fontSize:10,color:G,fontWeight:"900",letterSpacing:1.4},heroTitle:{fontSize:24,color:"#fff",fontWeight:"900",marginTop:6},heroCopy:{fontSize:12,color:"#aaa",lineHeight:18,marginTop:8},
filters:{flexDirection:"row",gap:7,marginBottom:20},filter:{borderWidth:1,borderColor:"#292929",borderRadius:18,paddingHorizontal:13,paddingVertical:8},filterActive:{backgroundColor:G,borderColor:G},filterText:{color:"#aaa",fontSize:10,fontWeight:"800"},filterActiveText:{color:"#090909"},section:{color:"#777",fontSize:10,fontWeight:"900",letterSpacing:1.5,marginBottom:9},
pick:{backgroundColor:CARD,borderWidth:1,borderColor:"#202020",borderRadius:15,padding:14,marginBottom:11},row:{flexDirection:"row",justifyContent:"space-between"},kicker:{fontSize:9,color:G,fontWeight:"900",letterSpacing:1},match:{fontSize:16,color:"#fff",fontWeight:"800",marginTop:4},conf:{alignItems:"flex-end"},confNum:{fontSize:18,color:G,fontWeight:"900"},confLabel:{fontSize:6,color:"#666",letterSpacing:1},priceRow:{flexDirection:"row",alignItems:"baseline",gap:10,marginTop:13},price:{fontSize:21,color:G,fontWeight:"900"},prob:{fontSize:11,color:"#aaa"},reason:{fontSize:12,color:"#c7c7c7",marginTop:7,lineHeight:17},meta:{fontSize:10,color:"#888",marginTop:6},btn:{marginTop:12,borderWidth:1,borderColor:"#5b4c1b",borderRadius:9,paddingVertical:10,alignItems:"center"},btnOn:{backgroundColor:"#1a170b"},btnText:{fontSize:10,color:G,fontWeight:"900",letterSpacing:1},
pageTitle:{fontSize:25,color:"#fff",fontWeight:"900",marginTop:4},muted:{fontSize:11,color:"#777",marginTop:4},empty:{backgroundColor:CARD,padding:32,borderRadius:15,alignItems:"center",marginTop:20},emptyTitle:{fontSize:18,color:"#fff",fontWeight:"800",marginTop:10},total:{backgroundColor:"#0f0d08",borderWidth:1,borderColor:"#4a3d1b",padding:16,borderRadius:14,marginTop:4},totalLabel:{fontSize:9,color:G,fontWeight:"900",letterSpacing:1.3},totalNum:{fontSize:20,color:"#fff",fontWeight:"900",marginTop:5},disclaimer:{fontSize:9,color:"#777",lineHeight:14,marginTop:7},
news:{flexDirection:"row",gap:12,backgroundColor:CARD,padding:14,borderRadius:14,marginTop:12},newsIcon:{width:42,height:42,borderRadius:10,backgroundColor:"#17150d",alignItems:"center",justifyContent:"center"},newsTitle:{fontSize:14,color:"#fff",fontWeight:"800",marginTop:5,lineHeight:19},moreRow:{height:59,borderBottomWidth:1,borderBottomColor:"#1d1d1d",flexDirection:"row",alignItems:"center",gap:13},moreText:{flex:1,color:"#fff",fontSize:14,fontWeight:"600"},notice:{marginTop:20,padding:14,borderRadius:12,borderWidth:1,borderColor:"#443818",backgroundColor:"#100e08"},noticeText:{color:"#b8aa7b",fontSize:10,lineHeight:16},
nav:{position:"absolute",bottom:0,left:0,right:0,height:76,backgroundColor:"#0a0a0a",borderTopWidth:1,borderTopColor:"#202020",flexDirection:"row",justifyContent:"space-around",paddingTop:9},navItem:{alignItems:"center",minWidth:57},navText:{fontSize:8,color:M,marginTop:4},navActive:{color:G,fontWeight:"900"}
});